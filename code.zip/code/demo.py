from neuroshape import NIIProcessor, ReconstructionPipeline, VolumeVisualizer
import numpy as np
import nibabel as nib
import pyvista as pv
from scipy.spatial import cKDTree

def clip_mesh_with_template(target_mesh, template_mesh, voxel_size=1.0):
    """使用原始网格模板切割优化后的网格"""
    # Step 1: 创建规则网格
    bounds = template_mesh.bounds
    dim_x = int(np.ceil((bounds[1] - bounds[0]) / voxel_size)) + 1
    dim_y = int(np.ceil((bounds[3] - bounds[2]) / voxel_size)) + 1
    dim_z = int(np.ceil((bounds[5] - bounds[4]) / voxel_size)) + 1
    
    grid = pv.ImageData(
        dimensions=(dim_x, dim_y, dim_z),
        spacing=(voxel_size,)*3,
        origin=(bounds[0], bounds[2], bounds[4])
    )
    
    # Step 2: 采样模板网格
    sampled = template_mesh.sample(grid)
    inside_points = sampled.points
    
    # Step 3: 创建KDTree
    tree = cKDTree(inside_points)
    
    # Step 4: 计算目标网格点到最近模板点的距离
    dist, _ = tree.query(target_mesh.points)
    
    # Step 5: 根据距离阈值提取点云
    threshold = voxel_size * 1.5
    mask = dist < threshold
    
    # Step 6: 重建裁剪网格（转换为PolyData）
    clipped = target_mesh.extract_points(mask)
    clipped = clipped.extract_surface().triangulate()  # 关键修正
    
    # Step 7: 后处理优化
    clipped = clipped.clean()
    clipped = clipped.smooth(n_iter=50)  # 现在支持smooth方法
    clipped = clipped.fill_holes(hole_size=1000)
    
    return clipped

# 1. 数据预处理
processor = NIIProcessor("/Users/a1/Desktop/MICCAI/data/BraTS2021_00000_seg.nii.gz")
mask = processor.load().get_tumor_mask(labels=(1,))  # 指定标签为1

if np.all(mask == 0):
    print("警告：掩模中没有肿瘤区域，mask 全为 0")
else:
    print("掩模提取成功，有肿瘤区域")

print(f"肿瘤区域的体素数：{np.sum(mask)}")

# 2. 配置参数
config = {
    'voxel_size': 1.0,
    'threshold': np.mean(mask) + np.std(mask),
    'epsilon': 1e-3,
    'neighbor_radius': 2.0,
    'curvature_threshold_low': 0.05,
    'curvature_threshold_high': 0.2
}

# 3. 执行重建
pipeline = ReconstructionPipeline(config)
mesh = pipeline.execute(mask)
reconstructed_mesh = pipeline.execute_with_surface_optimization(mesh)

# 新增裁剪步骤
clipped_mesh = clip_mesh_with_template(
    reconstructed_mesh, 
    mesh, 
    voxel_size=config['voxel_size']
)

# 4. 可视化
viz = VolumeVisualizer()
viz.add_mesh(clipped_mesh, color='#FF6B6B', opacity=0.8)
viz.add_mesh(mesh, color='#4ECDC4', opacity=0.3)
viz.show()