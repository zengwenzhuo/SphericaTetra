import numpy as np

class SurfaceGenerationAndOptimization:
    def __init__(self, mesh, sigma=0.5):
        self.mesh = mesh
        self.sigma = sigma  # 用于MLS平滑的带宽参数

    def catmull_clark_subdivision(self):
        """执行Catmull-Clark细分（仅对表面点）"""
        vertices = self.mesh.points
        faces = self.mesh.faces.reshape((-1, 3))  # 假设面是三角形

        # 获取所有表面顶点
        surface_vertices = set(np.unique(faces))
        print(f"Total surface vertices: {len(surface_vertices)}")

        # 1. 生成面顶点
        face_vertices = [np.mean(vertices[face], axis=0) for face in faces]

        # 2. 生成边顶点
        edge_to_index = {}  # 存储边到边顶点索引的映射
        edge_vertices = []
        for face in faces:
            for i in range(3):
                e0, e1 = face[i], face[(i+1)%3]
                edge = tuple(sorted([e0, e1]))
                if edge not in edge_to_index:
                    edge_vertex = np.mean(vertices[[e0, e1]], axis=0)
                    edge_vertices.append(edge_vertex)
                    edge_to_index[edge] = len(edge_vertices) - 1

        # 3. 更新原顶点位置
        updated_vertices = np.array(vertices.copy())
        for i in surface_vertices:
            # 获取相邻的面
            adjacent_faces = [face for face in faces if i in face]
            if not adjacent_faces:
                continue
            
            # 获取相邻的面顶点
            F_points = []
            for face in adjacent_faces:
                mask = (faces == face).all(axis=1)
                face_idx = np.where(mask)[0][0]
                F_points.append(face_vertices[face_idx])
            F = np.mean(F_points, axis=0)
            
            # 获取相邻的边顶点
            E_points = []
            for face in adjacent_faces:
                for j in range(3):
                    v0, v1 = face[j], face[(j+1)%3]
                    if i == v0 or i == v1:
                        edge = tuple(sorted([v0, v1]))
                        if edge in edge_to_index:
                            E_points.append(edge_vertices[edge_to_index[edge]])
            if not E_points:
                continue
            E = np.mean(E_points, axis=0)
            
            # 计算新顶点位置
            n = len(adjacent_faces)
            updated_vertices[i] = ((n - 2) * vertices[i] + E + F) / n

        # 合并所有顶点
        total_vertices = np.vstack([updated_vertices, face_vertices, edge_vertices])

        # 4. 生成新面
        new_faces = []
        num_original_vertices = len(updated_vertices)
        num_face_vertices = len(face_vertices)
        for face_idx, face in enumerate(faces):
            A, B, C = face
            # 获取边顶点索引
            edges = [
                tuple(sorted([A, B])),
                tuple(sorted([B, C])),
                tuple(sorted([C, A]))
            ]
            E_indices = []
            for edge in edges:
                if edge in edge_to_index:
                    E_idx = num_original_vertices + num_face_vertices + edge_to_index[edge]
                    E_indices.append(E_idx)
                else:
                    # 边不存在，可能逻辑错误
                    raise ValueError(f"Edge {edge} not found in edge_to_index")
            
            E_AB, E_BC, E_CA = E_indices
            F_idx = num_original_vertices + face_idx

            # 生成三个四边形面
            new_faces.extend([4, A, E_AB, F_idx, E_CA])
            new_faces.extend([4, E_AB, B, E_BC, F_idx])
            new_faces.extend([4, F_idx, E_BC, C, E_CA])

        # 更新网格
        self.mesh.points = total_vertices
        self.mesh.faces = new_faces
        print(f"Subdivision completed. New faces: {len(new_faces) // 5}")  # 每个面5个元素

    def mls_smoothing(self):
        """使用MLS平滑优化顶点位置（仅平滑表面顶点）"""
        vertices = self.mesh.points.copy()
        surface_vertices = set(np.unique(self.mesh.faces))
        for i in surface_vertices:
            v = vertices[i]
            distances = np.linalg.norm(vertices - v, axis=1)
            weights = np.exp(-distances**2 / (2 * self.sigma**2))
            weights[i] = 0  # 排除自身
            weighted_sum = np.sum(weights[:, np.newaxis] * vertices, axis=0)
            total_weight = np.sum(weights)
            if total_weight > 1e-6:
                vertices[i] = weighted_sum / total_weight
        self.mesh.points = vertices

    def generate_and_optimize_surface(self):
        """执行曲面生成与优化"""
        self.catmull_clark_subdivision()
        print("Catmull-Clark细分完成")

        self.mls_smoothing()
        print("MLS平滑完成")

        return self.mesh