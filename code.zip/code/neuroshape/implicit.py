import numpy as np
from scipy.sparse import lil_matrix, csr_matrix, hstack, vstack
from scipy.sparse.linalg import spsolve

class RBFReconstructor:
    def __init__(self, epsilon=1e-3, poly_order=1):
        self.epsilon = epsilon
        self.poly_order = poly_order
    
    def build_system(self, points, values):
        """Build sparse RBF system with polynomial terms"""
        n = len(points)
        d = points.shape[1]
        
        # Build RBF matrix
        Phi = lil_matrix((n, n))
        for i in range(n):
            for j in range(i, n):
                r = np.linalg.norm(points[i] - points[j])
                val = np.exp(-(self.epsilon * r)**2)
                Phi[i, j] = val
                if i != j:
                    Phi[j, i] = val
        
        # Build polynomial matrix
        P = self._build_polynomial_matrix(points)
        
        # Assemble full system
        A_top = hstack([Phi, P])
        A_bottom = hstack([P.T, lil_matrix((P.shape[1], P.shape[1]))])
        A = vstack([A_top, A_bottom]).tocsr()
        
        # Build RHS
        b = np.hstack([values, np.zeros(P.shape[1])])
        
        return A, b
    
    def _build_polynomial_matrix(self, points):
        """Create polynomial terms based on order"""
        n = points.shape[0]
        if self.poly_order == 1:
            return np.hstack([np.ones((n, 1)), points])
        elif self.poly_order == 2:
            return np.hstack([
                np.ones((n, 1)),
                points,
                points**2,
                points.prod(axis=1)[:, None]
            ])
        else:
            return np.ones((n, 1))
    
    def solve(self, A, b):
        """Solve sparse linear system"""
        return spsolve(A, b)