import numpy as np
from sklearn.neighbors import KDTree

class SphereCell:
    def __init__(self, center, radius, level=0):
        self.center = np.array(center, dtype=np.float32)
        self.radius = float(radius)
        self.level = int(level)
        self.samples = []
    
    def generate_samples(self):
        phi = (1 + np.sqrt(5)) / 2
        base_points = np.array([
            [0, 1, phi], [0, -1, phi], [0, 1, -phi], [0, -1, -phi],
            [1, phi, 0], [-1, phi, 0], [1, -phi, 0], [-1, -phi, 0],
            [phi, 0, 1], [-phi, 0, 1], [phi, 0, -1], [-phi, 0, -1]
        ], dtype=np.float32)
        norms = np.linalg.norm(base_points, axis=1)
        base_points = base_points / norms[:, None] * self.radius
        self.samples = base_points + self.center

class SpatialIndex:
    def __init__(self, cells):
        if not cells:
            raise ValueError("无效输入：cells列表为空。")
        
        centers = np.array([c.center for c in cells], dtype=np.float32)
        if centers.ndim != 2 or centers.shape[1] != 3:
            raise ValueError(f"期望中心点为(N,3)数组，实际形状：{centers.shape}")
        
        self.tree = KDTree(centers)
        self.cells = cells

    def query_radius(self, center, radius):
        """查询指定半径内的邻近球体单元"""
        # 确保输入为二维数组 (1,3)
        center = np.asarray(center).reshape(1, -1)
        
        # 查询邻近单元索引
        indices = self.tree.query_radius(center, r=radius)
        
        # 返回对应的球体单元对象
        return [self.cells[i] for i in indices[0]]