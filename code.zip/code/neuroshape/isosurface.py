import numpy as np
from enum import IntEnum

class TetrahedronCase(IntEnum):
    """定义四面体所有可能的等值面情况"""
    CASE_0 = 0   # 0000 - 全部在等值面外
    CASE_1 = 1   # 0001
    CASE_2 = 2   # 0010
    CASE_3 = 3   # 0011
    CASE_4 = 4   # 0100
    CASE_5 = 5   # 0101
    CASE_6 = 6   # 0110
    CASE_7 = 7   # 0111
    CASE_8 = 8   # 1000
    CASE_9 = 9   # 1001
    CASE_10 = 10 # 1010
    CASE_11 = 11 # 1011
    CASE_12 = 12 # 1100
    CASE_13 = 13 # 1101
    CASE_14 = 14 # 1110
    CASE_15 = 15 # 1111 - 全部在等值面内

# 四面体边连接表（每个情况对应的边索引）
# 索引对应四面体的6条边：
# 0: (0,1), 1: (0,2), 2: (0,3)
# 3: (1,2), 4: (1,3), 5: (2,3)
EDGE_TABLE = {
    TetrahedronCase.CASE_0: [],
    TetrahedronCase.CASE_1: [0, 2, 3],
    TetrahedronCase.CASE_2: [0, 1, 4],
    TetrahedronCase.CASE_3: [1, 2, 3, 3, 4, 1],
    TetrahedronCase.CASE_4: [1, 3, 5],
    TetrahedronCase.CASE_5: [0, 2, 3, 1, 3, 5],
    TetrahedronCase.CASE_6: [0, 1, 4, 1, 3, 5],
    TetrahedronCase.CASE_7: [2, 3, 4, 3, 5, 4],
    TetrahedronCase.CASE_8: [2, 4, 5],
    TetrahedronCase.CASE_9: [0, 2, 3, 2, 4, 5],
    TetrahedronCase.CASE_10: [0, 1, 4, 2, 4, 5],
    TetrahedronCase.CASE_11: [1, 3, 4, 3, 5, 4, 0, 1, 4],
    TetrahedronCase.CASE_12: [1, 2, 5, 3, 5, 1],
    TetrahedronCase.CASE_13: [0, 2, 3, 1, 2, 5],
    TetrahedronCase.CASE_14: [0, 1, 4, 2, 5, 1],
    TetrahedronCase.CASE_15: []
}

# 顶点顺序约定：
# 顶点索引：0,1,2,3
# 四面体边映射：
EDGE_VERTEX_MAP = [
    (0, 1),  # 边0
    (0, 2),  # 边1
    (0, 3),  # 边2
    (1, 2),  # 边3
    (1, 3),  # 边4
    (2, 3)   # 边5
]

class MarchingTetrahedra:
    def __init__(self, threshold):
        self.threshold = threshold
        self.edge_table = EDGE_TABLE
    
    def process_tetrahedron(self, vertices, values):
        """
        处理单个四面体，生成等值面三角形
        
        参数：
            vertices : (4,3)数组，四面体顶点坐标
            values   : (4,)数组，顶点处的标量值
            
        返回：
            triangles : (N,3,3)数组，三角形顶点坐标
        """
        case = self._calculate_case(values)
        edges = self.edge_table.get(case, [])
        
        triangles = []
        for i in range(0, len(edges), 3):
            if i+2 >= len(edges):
                break
                
            # 获取三条边索引
            e0, e1, e2 = edges[i], edges[i+1], edges[i+2]
            
            # 计算交点
            p0 = self._calculate_edge_intersection(vertices, values, e0)
            p1 = self._calculate_edge_intersection(vertices, values, e1)
            p2 = self._calculate_edge_intersection(vertices, values, e2)
            
            if p0 is None or p1 is None or p2 is None:
                continue

                
            # 检查三角形有效性
            if self._is_valid_triangle(p0, p1, p2):
                triangles.append([p0, p1, p2])
        
        return np.array(triangles, dtype=np.float32) if triangles else np.empty((0,3,3))
    
    def _calculate_case(self, values):
        """根据顶点值确定情况索引"""
        case_code = 0

        self.threshold = np.median(values)

        for i, v in enumerate(values):
            #print(f"i={i}, v={v}, threshold={self.threshold}")  # 打印调试信息
            if v >= self.threshold:
                #print(f"Updating case_code with: 1 << {i} = {1 << i}")  # 打印更新信息
                case_code |= 1 << i
            #print(f"Updated case_code={case_code}")  # 打印更新后的case_code
        return TetrahedronCase(case_code)
    
    def _calculate_edge_intersection(self, vertices, values, edge_index):
        """计算边上的等值面交点"""
        if edge_index < 0 or edge_index >= 6:
            return None
        
        v0_idx, v1_idx = EDGE_VERTEX_MAP[edge_index]
        v0_val = values[v0_idx]
        v1_val = values[v1_idx]
        
        # 检查是否需要插值
        if (v0_val - self.threshold) * (v1_val - self.threshold) >= 0:
            return None
        
        # 线性插值
        t = (self.threshold - v0_val) / (v1_val - v0_val + 1e-8)
        return vertices[v0_idx] + t * (vertices[v1_idx] - vertices[v0_idx])
    
    def _is_valid_triangle(self, p0, p1, p2, eps=1e-6):
        """验证三角形是否有效（非退化的）"""
        vec1 = p1 - p0
        vec2 = p2 - p0
        cross = np.cross(vec1, vec2)
        return np.linalg.norm(cross) > eps
    
    @staticmethod
    def get_tetra_edges():
        """获取四面体边定义（用于可视化调试）"""
        return [
            (0, 1), (0, 2), (0, 3),
            (1, 2), (1, 3), (2, 3)
        ]