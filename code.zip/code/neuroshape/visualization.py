import pyvista as pv
from pyvista import themes
import numpy as np

class VolumeVisualizer:
    def __init__(self):
        self.plotter = pv.Plotter()
        self._setup_theme()
    
    def _setup_theme(self):
        theme = themes.DocumentTheme()
        theme.background = 'white'
        theme.font.color = 'black'
        theme.colorbar_orientation = 'horizontal'
        pv.set_plot_theme(theme)
    
    def add_mesh(self, mesh, color='red', opacity=0.8):
        """Add reconstructed mesh"""
        self.plotter.add_mesh(mesh, color=color, opacity=opacity)
    
    def add_volume_slices(self, volume, cmap='gray'):
        """Add orthogonal slices"""
        grid = pv.wrap(volume)

        dim = np.array(volume.shape) // 2
        # Use slice() method for slicing the volume along different axes
        slice_x = grid.slice(normal='x', origin=(dim[0], 0, 0))
        slice_y = grid.slice(normal='y', origin=(0, dim[1], 0))
        slice_z = grid.slice(normal='z', origin=(0, 0, dim[2]))

        # Add slices to the plotter
        self.plotter.add_mesh(slice_x, cmap=cmap, opacity=0.3)
        self.plotter.add_mesh(slice_y, cmap=cmap, opacity=0.3)
        self.plotter.add_mesh(slice_z, cmap=cmap, opacity=0.3)
    
    def show(self):
        """Render visualization"""
        self.plotter.show()

    def save_screenshot(self, filename):
        """Save visualization to file"""
        self.plotter.screenshot(filename)