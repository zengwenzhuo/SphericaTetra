import numpy as np
import pyvista as pv
import time
from tqdm import tqdm
import psutil
from skimage import measure
from scipy.spatial import KDTree
from numpy.fft import fft
from .spatial import SphereCell, SpatialIndex
from .implicit import RBFReconstructor
from .isosurface import MarchingTetrahedra
from .surface import SurfaceGenerationAndOptimization

class ReconstructionPipeline:
    def __init__(self, config, sigma=5.0):
        self.config = config
        self.sigma = sigma
        self.mc_mesh = None  # 存储MC算法生成的网格
        self.mc_metrics = {}  # 存储MC算法性能指标
        self.custom_metrics = {}  # 存储自定义算法指标
        self.rbf = RBFReconstructor(epsilon=config['epsilon'])
        self.mt = MarchingTetrahedra(threshold=config['threshold'])

    def generate_mc_mesh(self, volume):
        """生成Marching Cubes基准网格"""
        start_time = time.time()
        process = psutil.Process()
        start_mem = process.memory_info().rss
        
        try:
            verts, faces, _, _ = measure.marching_cubes(
                volume,
                level=self.config['threshold'],
                spacing=(self.config['voxel_size'],)*3
            )
            # 转换为PyVista格式
            faces_pv = np.insert(faces, 0, 3, axis=1)
            self.mc_mesh = pv.PolyData(verts, faces_pv)
            
            # 后处理
            self.mc_mesh = self.mc_mesh.smooth(n_iter=50)
            
            # 记录性能指标
            self.mc_metrics = {
                'Time': (time.time() - start_time) / 60,
                'MemoryPeak': (process.memory_info().rss - start_mem) / 1024**3
            }
            return self.mc_mesh
        except Exception as e:
            print(f"MC网格生成失败: {str(e)}")
            return None

    def evaluate_metrics(self, reconstructed_mesh):
        """计算曲率复杂度、高频能量保留、特征锐度"""
        if self.mc_mesh is None:
            raise ValueError("请先调用generate_mc_mesh生成基准网格")
            
        metrics = {}

        # 曲率复杂度 (Std)
        custom_curvature = self._calculate_curvature_metrics(reconstructed_mesh)
        mc_curvature = self._calculate_curvature_metrics(self.mc_mesh)
        
        # 高频能量保留 (dB)
        custom_high_freq = self._calculate_high_freq_power(reconstructed_mesh)
        mc_high_freq = self._calculate_high_freq_power(self.mc_mesh)
        
        # 特征锐度 (°)
        custom_sharpness = self._calculate_feature_sharpness(reconstructed_mesh)
        mc_sharpness = self._calculate_feature_sharpness(self.mc_mesh)
        
        metrics.update({
            'Custom_CurvatureStd': custom_curvature['CurvatureStd'],
            'MC_CurvatureStd': mc_curvature['CurvatureStd'],
            'Custom_HighFreq': custom_high_freq['HighFreqPower'],
            'MC_HighFreq': mc_high_freq['HighFreqPower'],
            'Custom_Sharpness': custom_sharpness['AvgSharpness'],
            'MC_Sharpness': mc_sharpness['AvgSharpness']
        })
        
        return metrics
    
    def _calculate_curvature_metrics(self, mesh):
        """计算表面曲率标准差"""
        curvatures = mesh.curvature('mean')  # 使用PyVista内置曲率计算
        return {
            'CurvatureMean': np.mean(curvatures),
            'CurvatureStd': np.std(curvatures)
        }
    
    def _calculate_high_freq_power(self, mesh):
        """通过FFT分析高频细节"""
        def fft_analysis(points):
            freq_powers = []
            for coord in [0, 1, 2]:  # 分别处理X/Y/Z坐标
                signal = points[:, coord]
                
                # 标准化信号
                signal = (signal - np.mean(signal)) / (np.std(signal) + 1e-7)
                
                # 添加汉宁窗减少频谱泄漏
                window = np.hanning(len(signal))
                fft_result = fft(window * signal)
                
                # 计算高频能量（取1/3以上频段）
                n = len(fft_result)
                high_freq = np.abs(fft_result[n//3 : n//2]).mean()  # 取1/3~1/2频段
                freq_powers.append(high_freq)
                
            return np.mean(freq_powers)

        return {
            'HighFreqPower': fft_analysis(mesh.points)
        }
    
    def _calculate_feature_sharpness(self, mesh):
        """基于梯度计算特征锐度"""
        edges = mesh.extract_feature_edges(
            feature_angle=30,  # 可调整角度阈值
            boundary_edges=False,
            non_manifold_edges=False
        )
        sharpness = []
        for edge in edges.points:
            # 计算相邻面法向量夹角
            adjacent_faces = mesh.find_cells_along_line(edge-0.1, edge+0.1)
            if len(adjacent_faces) >= 2:
                n1 = mesh.cell_normals[adjacent_faces[0]]
                n2 = mesh.cell_normals[adjacent_faces[1]]
                angle = np.degrees(np.arccos(np.dot(n1, n2)))
                sharpness.append(180 - angle)
        return {
            'AvgSharpness': np.mean(sharpness) if sharpness else 0,
            'MaxSharpness': np.max(sharpness) if sharpness else 0
        }
    
    def _calc_non_manifold_ratio(self, mesh):
        """手动计算非流形边比例（带调试输出）"""
        if mesh.n_faces == 0:
            print("警告：空网格，无法计算非流形边")
            return 0.0

        edge_counter = {}
        print(f"开始处理网格，总面数：{mesh.n_faces}")

        # 动态解析面数据
        faces = mesh.faces
        i = 0
        while i < len(faces):
            n_vertices = faces[i]
            vertices = faces[i+1 : i+1+n_vertices]
            i += 1 + n_vertices
            
            print(f"处理面：顶点数={n_vertices}，顶点索引={vertices}")
            
            # 生成所有边
            for j in range(n_vertices):
                edge = tuple(sorted((
                    vertices[j], 
                    vertices[(j+1) % n_vertices]
                )))
                print(f"发现边：{edge}")
                edge_counter[edge] = edge_counter.get(edge, 0) + 1

        # 统计结果输出
        print("\n边统计结果：")
        for edge, count in edge_counter.items():
            print(f"边 {edge} 被 {count} 个面共享")
        
        non_manifold = sum(1 for cnt in edge_counter.values() if cnt >= 3)
        total_edges = len(edge_counter)
        ratio = (non_manifold / total_edges * 100) if total_edges > 0 else 0
        
        print(f"\n非流形边统计：")
        print(f"总边数：{total_edges}")
        print(f"非流形边数：{non_manifold}")
        print(f"非流形边比例：{ratio:.2f}%")
        
        return ratio

    def _count_holes(self, mesh):
        """计算孔洞数量"""
        boundaries = mesh.extract_feature_edges(boundary_edges=True)
        return boundaries.n_lines // 3  # 经验公式

    def _count_components(self, mesh):
        """计算连通组件数"""
        return len(mesh.split_bodies())
    
    def print_metrics_report(self, metrics):
        """打印计算的各项指标对比报告"""
        print(f"曲率复杂度 (Std): {metrics['Custom_CurvatureStd']:.2f} | {metrics['MC_CurvatureStd']:.2f} | "
              f"↑ {metrics['Custom_CurvatureStd'] - metrics['MC_CurvatureStd']:.2f} "
              f"({(metrics['Custom_CurvatureStd'] - metrics['MC_CurvatureStd']) / metrics['MC_CurvatureStd'] * 100:.1f}%)")
        
        print(f"高频能量保留 (dB): {metrics['Custom_HighFreq']:.2f} dB | {metrics['MC_HighFreq']:.2f} dB | "
              f"↑ {metrics['Custom_HighFreq'] - metrics['MC_HighFreq']:.2f} "
              f"({(metrics['Custom_HighFreq'] - metrics['MC_HighFreq']) / metrics['MC_HighFreq'] * 100:.1f}%)")
        
        print(f"特征锐度 (°): {metrics['Custom_Sharpness']:.2f}° | {metrics['MC_Sharpness']:.2f}° | "
              f"↑ {metrics['Custom_Sharpness'] - metrics['MC_Sharpness']:.2f} "
              f"({(metrics['Custom_Sharpness'] - metrics['MC_Sharpness']) / metrics['MC_Sharpness'] * 100:.1f}%)")

    def _print_detail_metric(self, name, mc_val, custom_val, unit='', reverse=True):
        """专用于细节指标的格式化输出"""
        delta = custom_val - mc_val if not reverse else mc_val - custom_val
        percentage = abs(delta / (mc_val + 1e-7) * 100)  # 防止除零
        
        print(f"{name:<25} | {mc_val:.2f}{unit:<5} | {custom_val:.2f}{unit:<5} | "
              f"{'↑' if delta>0 else '↓'} {abs(delta):.2f}{unit} ({percentage:.1f}%)")

    def _print_metric_row(self, name, mc_val, custom_val, reverse=True):
        """格式化单行指标输出"""
        custom_val = custom_val / 100
        if mc_val == 0:
            improvement = 'N/A'
        else:
            delta = (mc_val - custom_val) if reverse else (custom_val - mc_val)
            percentage = abs(delta / mc_val * 100)
            improvement = f"{percentage:.1f}% {'↑' if delta > 0 else '↓'}"
        
        print(f"{name:<25} | {mc_val:<15.3f} | {custom_val:<15.3f} | {improvement:<15}")

    def execute_with_surface_optimization(self, mesh):
        """在执行完重建后，进行曲面优化"""
        # 执行常规重建
        #mesh = self.execute(volume)

        # 泊松重建
        poisson_mesh = mesh.reconstruct_surface()
        poisson_mesh = poisson_mesh.smooth(n_iter=200)
        #poisson_mesh = pv.filters.smooth_laplacian(n_iter=200)  # 拉普拉斯平滑消除高频噪声
        #poisson_mesh = pv.filters.smooth_moving_average(n_iter=100)  # 移动平均平滑中频特征
        #poisson_mesh = pv.filters.smooth_taubin(n_iter=50)      # Taubin方法保持体积
        
        # 孔洞填充
        #poisson_mesh.fill_holes(hole_size=2000)
        
        return poisson_mesh
    
    def execute(self, volume):
        """Full reconstruction pipeline"""
        # 1. Generate sphere cells
        cells = self._create_sphere_cells(volume)
        spatial_index = SpatialIndex(cells)
        
        # 2. Process each cell
        mesh = pv.PolyData()
        for cell in tqdm(cells, desc="Processing cells"):
            # 2.1 Adaptive subdivision
            self._adaptive_subdivision(cell, volume)
            
            # 2.2 Collect neighborhood data
            neighbors = spatial_index.query_radius(
                cell.center, 
                self.config['neighbor_radius']
            )
            points, values = self._collect_samples(cell, neighbors, volume)
            
            # 2.3 Fit RBF
            A, b = self.rbf.build_system(points, values)
            try:
                coeffs = self.rbf.solve(A, b)
                #print(f"Calculated coefficients: {coeffs}")
            except:
                continue
            
            # 2.4 Extract isosurface
            tetrahedra = self._decompose_tetrahedra(cell)
            # neuroshape/pipeline.py
            for tetra in tetrahedra:
                # tetra 是形状为 (4,) 的索引数组，例如 [0, 1, 2, 3]
                # 从 cell.samples 中获取实际顶点坐标
                verts = [cell.samples[i] + cell.center for i in tetra]
                # 获取顶点处的标量值（示例代码需根据实际数据调整）
                vals = [sum(c * self._basis_function(v, sample) for c, sample in zip(coeffs, cell.samples)) for v in verts]
                #print(f"Calculated values for verts: {vals}")
                #print(f"Verts: {verts}, Cell center: {cell.center}")

                # 生成三角形
                # 假设原始数据为分割掩膜（0 和 1）
                vals = np.array(vals)
                vals = (vals - vals.min()) / (vals.max() - vals.min())
                triangles = self.mt.process_tetrahedron(verts, vals)
                print(f"Generated {len(triangles)} triangles.")
                self._add_to_mesh(mesh, triangles)
        
        return mesh
    
    def _basis_function(self, v, center):
        # 计算欧氏距离平方
        squared_dist = np.sum((np.array(v) - np.array(center))**2)
        # 应用高斯核函数，其中sigma为带宽参数
        return np.exp(-squared_dist / (2 * self.sigma**2))
    
    def _create_sphere_cells(self, volume):
        """Generate sphere cells from volume"""
        coords = np.argwhere(volume > 0)
        sphere_cells = [
            SphereCell(
                center=coord.astype(float) + 0.5,
                radius=self.config['voxel_size'] / 2,
                level=0
            )
            for coord in coords
        ]
        
        # 打印生成的球形单元数量
        print(f"一共生成了 {len(sphere_cells)} 个球形单元")
        
        return sphere_cells
    
    def _adaptive_subdivision(self, cell, volume):
        """Curvature-based subdivision"""
        # 高斯滤波预处理
        from scipy.ndimage import gaussian_filter
        smoothed = gaussian_filter(volume.astype(float), sigma=2.0)

        # Calculate local curvature
        grad = np.gradient(smoothed)
        hessian = [np.gradient(g) for g in grad]
        curvature = np.linalg.norm(hessian) / (np.linalg.norm(grad) + 1e-7)
        
        # Determine subdivision level
        if curvature > self.config['curvature_threshold_high']:
            cell.level = 2
        elif curvature > self.config['curvature_threshold_low']:
            cell.level = 1
        else:
            cell.level = 0
         
        cell.generate_samples()
    
    def _collect_samples(self, cell, neighbors, volume):
        """Collect sample points and values"""
        points = []
        values = []
        for neighbor in neighbors:
            for sample in neighbor.samples:
                idx = np.round(sample).astype(int)
                if np.all(idx >= 0) and np.all(idx < volume.shape):
                    points.append(sample)
                    values.append(volume[tuple(idx)])
        return np.array(points), np.array(values)
    
    def _decompose_tetrahedra(self, cell):
        """将球体分解为四面体，返回顶点索引数组"""
        from scipy.spatial import Delaunay
        try:
            # Delaunay 三角剖分返回四面体顶点索引
            tri = Delaunay(cell.samples)
            return tri.simplices  # 直接返回索引数组，形状为 (N,4)
        except Exception as e:
            print(f"Delaunay 分解失败: {str(e)}")
            return []
    
    def _add_to_mesh(self, mesh, triangles):
        """Merge triangles into PyVista mesh"""
        for tri in triangles:
            if len(tri) != 3:
                continue
            points = np.array(tri)
            faces = np.hstack([[3], np.arange(len(mesh.points), len(mesh.points)+3)])
            mesh.points = np.vstack([mesh.points, points])
            mesh.faces = np.hstack([mesh.faces, faces])

        # Ensure mesh is not empty
        #if mesh.points.size == 0:
            #print("Mesh is empty, no points added!")
        #else:
            #print(f"Mesh contains {len(mesh.points)} points.")