neuroshape/
├── __init__.py
├── preprocessing.py
├── spatial.py
├── implicit.py
├── isosurface.py
├── pipeline.py
└── visualization.py