import nibabel as nib
import numpy as np
from scipy import ndimage
from skimage import morphology
import matplotlib.pyplot as plt

class NIIProcessor:
    def __init__(self, path):
        self.path = path
        self.img = None
        self.data = None
        self.affine = None
    
    def load(self):
        self.img = nib.load(self.path)
        self.data = self.img.get_fdata().astype(np.float32)
        self.affine = self.img.affine
        return self
    
    def normalize(self):
        #mask = self.data > 0
        #if np.any(mask):
            #self.data = (self.data - self.data[mask].mean()) / self.data[mask].std()
        return self
    
    def get_tumor_mask(self, labels=(1,), closing_radius=3):
        # 生成初始二值掩模
        mask = np.isin(self.data, labels).astype(np.uint8)
        
        # 异常检测
        if np.sum(mask) < 10:  # 至少包含10个体素
            raise ValueError("肿瘤区域体素数不足，请检查标签数据")
            
        # 形态学优化序列
        struct = morphology.ball(closing_radius)
        mask = ndimage.binary_closing(mask, structure=struct)  # 优先闭运算处理小孔洞
        mask = ndimage.binary_opening(mask, structure=struct)  # 后开运算去除孤立噪声点

        # 添加连通区域筛选
        labeled_mask, num_labels = ndimage.label(mask)
        region_sizes = np.bincount(labeled_mask.ravel())
        main_region = region_sizes[1:].argmax() + 1  # 保留最大连通域
        mask = (labeled_mask == main_region).astype(np.float32)

        #print("肿瘤掩模数据（前100个体素）：")
        #print(mask.ravel()[:100])  # 打印前100个体素
        #print(f"掩模数据总数: {np.sum(mask)}")  # 输出掩模的体素总数

        print("数据中所有唯一标签值：", np.unique(self.data))
        print("肿瘤掩模的形状：", mask.shape)
        print("肿瘤掩模体素总数：", np.sum(mask))

        
        return mask
    
    def visualize_slice(self, mask, slice_idx=100, plane='axial'):
        # 建立切面方向映射
        axis_mapping = {
            'sagittal': 0,
            'coronal': 1,
            'axial': 2
        }
        
        # 验证切面参数有效性
        if plane not in axis_mapping:
            raise ValueError(f"无效切面方向: {plane}。可选值: {list(axis_mapping.keys())}")
        
        # 获取当前方向的维度限制
        axis = axis_mapping[plane]
        max_slices = self.data.shape[axis] - 1
        
        # 强制索引有效性
        if slice_idx < 0 or slice_idx > max_slices:
            raise IndexError(
                f"{plane}切面索引越界: 最大允许值 {max_slices} (当前请求 {slice_idx})\n"
                f"数据维度: {self.data.shape}"
            )
        
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        
        # 动态切片选择
        if plane == 'sagittal':
            raw_slice = self.data[slice_idx, :, :]
            mask_slice = mask[slice_idx, :, :]
        elif plane == 'coronal':
            raw_slice = self.data[:, slice_idx, :]
            mask_slice = mask[:, slice_idx, :]
        else:
            raw_slice = self.data[:, :, slice_idx]
            mask_slice = mask[:, :, slice_idx]
        
        # 可视化增强
        axes[0].imshow(raw_slice.T, cmap='gray', origin='lower')
        axes[0].set_title(f'原始图像 [{plane}切面]')
        
        axes[1].imshow(raw_slice.T, cmap='gray', origin='lower')
        axes[1].imshow(mask_slice.T, cmap='jet', alpha=0.3)
        axes[1].set_title('肿瘤区域分割')
        
        plt.tight_layout()
        
        # 体积计算优化
        voxel_size = nib.affines.voxel_sizes(self.affine)
        voxel_vol = np.prod(voxel_size) * (1e3 if max(voxel_size) > 10 else 1)  # 自动单位缩放
        tumor_vol = np.sum(mask) * voxel_vol
        fig.suptitle(f'肿瘤体积: {tumor_vol:.2f} mm³ | 层厚: {voxel_size[axis]:.2f}mm', y=0.95)
        
        plt.show()

if __name__ == "__main__":
    processor = NIIProcessor("/Users/a1/Desktop/MICCAI/BraTS2021_00000_seg_cropped.nii.gz").load()
    print(f"数据维度: {processor.data.shape}")
    
    try:
        tumor_mask = processor.get_tumor_mask()
        
        # 动态切片选择策略
        axial_slice = processor.data.shape[2] // 2  # 轴向中间切片
        sagittal_slice = processor.data.shape[0] // 2  # 矢状面中间切片
        
        processor.visualize_slice(tumor_mask, slice_idx=axial_slice, plane='axial')
        processor.visualize_slice(tumor_mask, slice_idx=sagittal_slice, plane='sagittal')
    except (ValueError, IndexError) as e:
        print(f"医学影像处理异常: {str(e)}")