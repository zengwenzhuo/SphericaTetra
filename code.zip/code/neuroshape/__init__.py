"""
NeuroShape - A Advanced 3D Medical Image Reconstruction Toolkit

This package provides algorithms for high-quality 3D reconstruction of medical images,
with focus on brain tumor segmentation and visualization.
"""

__version__ = "0.1.0"

# 主功能接口
from .preprocessing import NIIProcessor
from .spatial import SphereCell, SpatialIndex
from .implicit import RBFReconstructor
from .isosurface import MarchingTetrahedra
from .pipeline import ReconstructionPipeline
from .visualization import VolumeVisualizer

# 简化导入方式
__all__ = [
    'NIIProcessor',
    'SphereCell',
    'SpatialIndex',
    'RBFReconstructor',
    'MarchingTetrahedra',
    'ReconstructionPipeline',
    'VolumeVisualizer',
    'config_presets'  # 新增配置预设
]

# 预定义配置方案
config_presets = {
    'fast': {
        'voxel_size': 2.0,
        'threshold': 0.6,
        'epsilon': 1e-2,
        'neighbor_radius': 3.0,
        'curvature_threshold_low': 0.2,
        'curvature_threshold_high': 0.4
    },
    'high_quality': {
        'voxel_size': 0.5,
        'threshold': 0.5,
        'epsilon': 1e-3,
        'neighbor_radius': 2.0,
        'curvature_threshold_low': 0.1,
        'curvature_threshold_high': 0.3
    }
}

def about():
    """显示包信息"""
    print(f"NeuroShape {__version__}")
    print("Developed for MICCAI Brain Tumor Segmentation Challenge")
    print("Algorithm Features:")
    print("- Adaptive Spherical Sampling")
    print("- RBF Implicit Surface Reconstruction")
    print("- Curvature-aware Subdivision")
    print("- Multi-modal Fusion Support")