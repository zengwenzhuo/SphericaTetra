import nibabel as nib
import numpy as np
import matplotlib.pyplot as plt
from skimage import measure
from mpl_toolkits.mplot3d import Axes3D
import os

# 加载 NIfTI 文件
file_path = '/Users/a1/Desktop/MICCAI/data/BraTS2021_00000_seg.nii.gz'
img = nib.load(file_path)
segmentation_data = img.get_fdata()

# 假设脑肿瘤的标签值为 1，其他部分为 0
tumor_mask = segmentation_data == 1

# 使用 Marching Cubes 算法进行表面重建
verts, faces, _, _ = measure.marching_cubes(tumor_mask, level=0)

# 可视化三维模型
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# 绘制三维网格
ax.plot_trisurf(verts[:, 0], verts[:, 1], faces, verts[:, 2], cmap='Spectral', lw=1)

# 设置标题和轴标签
ax.set_title('Brain Tumor Surface Reconstruction')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# 显示模型
plt.show()
