from neuroshape import NIIProcessor, ReconstructionPipeline, VolumeVisualizer
import numpy as np
import nibabel as nib
from skimage import measure
import pyvista as pv

# 1. 数据预处理
processor = NIIProcessor("/Users/a1/Desktop/MICCAI/data/BraTS2021_00000_seg.nii.gz")
mask = processor.load().get_tumor_mask(labels=(1,))  # 指定标签为1

if np.all(mask == 0):
    print("警告：掩模中没有肿瘤区域，mask 全为 0")
else:
    print("掩模提取成功，有肿瘤区域")

# 输出掩模中肿瘤区域的数量
print(f"肿瘤区域的体素数：{np.sum(mask)}")

# 2. 配置参数
config = {
    'voxel_size': 1.0,
    'threshold': np.mean(mask) + np.std(mask),
    'epsilon': 1e-3,
    'neighbor_radius': 2.0,
    'curvature_threshold_low': 0.05,
    'curvature_threshold_high': 0.2
}

print(config['threshold'])

volume = np.zeros((64, 64, 64))
x, y, z = np.indices((64, 64, 64))
volume[(x-32)**2 + (y-32)**2 + (z-32)**2 < 20**2] = 1

# 运行重建流程
pipeline = ReconstructionPipeline(config)
#pipeline.original_volume = volume  # 保存原始体数据
mc_mesh = pipeline.generate_mc_mesh(mask)  # 生成传统MC算法的基准网格

# 运行本算法
#reconstructed_mesh = pipeline.execute(volume)
#reconstructed_mesh = pipeline.execute_with_surface_optimization(reconstructed_mesh)

# 计算指标
#metrics = pipeline.evaluate_metrics(reconstructed_mesh)

# 生成报告
#pipeline.print_metrics_report(metrics)

# 3. 执行重建
pipeline = ReconstructionPipeline(config)
mesh = pipeline.execute(mask)
reconstructed_mesh = pipeline.execute_with_surface_optimization(mesh)

# 将MC网格设为基准
pipeline.mc_mesh = mc_mesh  
metrics = pipeline.evaluate_metrics(reconstructed_mesh)
pipeline.print_metrics_report(metrics)

# 4. 可视化
viz = VolumeVisualizer()
viz.add_mesh(reconstructed_mesh, color='#FF6B6B', opacity=0.8)
#viz.add_volume_slices(mask, cmap='gray')
viz.show()